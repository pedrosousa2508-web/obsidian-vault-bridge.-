export interface Env { VAULT_NOTES: KVNamespace; BRIDGE_TOKEN: string; }
type StoredNote = { path: string; content: string; mtime: number; updatedAt: string };
type JsonRpcRequest = { jsonrpc: "2.0"; id?: string|number|null; method: string; params?: Record<string,unknown> };
const MAX_NOTE_BYTES = 512 * 1024; const MAX_SEARCH_RESULTS = 50;
function json(data: unknown, status=200){ return new Response(JSON.stringify(data),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}}); }
function rpcResult(id: JsonRpcRequest["id"], result: unknown){ return json({jsonrpc:"2.0",id:id??null,result}); }
function rpcError(id: JsonRpcRequest["id"], code:number, message:string, data?:unknown){ return json({jsonrpc:"2.0",id:id??null,error:{code,message,...(data===undefined?{}:{data})}}); }
function isAuthorized(request:Request, env:Env){ const expected=env.BRIDGE_TOKEN?.trim(); if(!expected)return false; return (request.headers.get("authorization")??"")===`Bearer ${expected}`; }
function safePath(value:unknown){ if(typeof value!=="string") throw new Error("path must be a string"); const path=value.trim().replace(/\\/g,"/"); if(!path||!path.endsWith(".md"))throw new Error("Only .md paths are allowed"); if(path.startsWith("/")||path.includes("../")||path===".."||path.startsWith(".obsidian/")||path.includes("/.obsidian/"))throw new Error("Unsafe path"); return path; }
function checkContent(content:unknown){ if(typeof content!=="string")throw new Error("content must be a string"); if(new TextEncoder().encode(content).byteLength>MAX_NOTE_BYTES)throw new Error("Note is too large"); return content; }
async function getNote(env:Env,path:string):Promise<StoredNote|null>{ return env.VAULT_NOTES.get(`note:${path}`,"json"); }
async function putNote(env:Env,path:string,content:string,mtime:number):Promise<StoredNote>{ const note={path,content,mtime:Number.isFinite(mtime)?mtime:Date.now(),updatedAt:new Date().toISOString()}; await env.VAULT_NOTES.put(`note:${path}`,JSON.stringify(note)); return note; }
async function listAllPaths(env:Env){ const paths:string[]=[]; let cursor:string|undefined=undefined; do{ const page=await env.VAULT_NOTES.list({prefix:"note:",cursor,limit:1000}); for(const key of page.keys)paths.push(key.name.slice(5)); cursor=page.list_complete?undefined:page.cursor; }while(cursor); return paths.sort((a,b)=>a.localeCompare(b)); }
async function searchNotes(env:Env,query:string){ const q=query.trim().toLocaleLowerCase(); const paths=await listAllPaths(env); const results:Array<{path:string;snippet:string;updatedAt:string}>=[]; for(const path of paths){ if(results.length>=MAX_SEARCH_RESULTS)break; const note=await getNote(env,path); if(!note)continue; const haystack=`${path}\n${note.content}`.toLocaleLowerCase(); if(!q||haystack.includes(q)){ const index=q?haystack.indexOf(q):0; const start=Math.max(0,index-120); const end=Math.min(note.content.length,start+400); results.push({path,snippet:note.content.slice(start,end),updatedAt:note.updatedAt}); } } return results; }
const TOOLS=[
{name:"list_notes",description:"List Markdown notes currently synchronized from the Obsidian vault.",inputSchema:{type:"object",properties:{},additionalProperties:false}},
{name:"search_notes",description:"Search synchronized Obsidian notes by path or text content.",inputSchema:{type:"object",properties:{query:{type:"string",description:"Text to search for."}},required:["query"],additionalProperties:false}},
{name:"read_note",description:"Read one synchronized Markdown note by its vault-relative path.",inputSchema:{type:"object",properties:{path:{type:"string"}},required:["path"],additionalProperties:false}},
{name:"write_note",description:"Create or replace a synchronized Markdown note.",inputSchema:{type:"object",properties:{path:{type:"string"},content:{type:"string"}},required:["path","content"],additionalProperties:false}},
{name:"delete_note",description:"Delete one synchronized Markdown note from the remote bridge.",inputSchema:{type:"object",properties:{path:{type:"string"}},required:["path"],additionalProperties:false}}
] as const;
async function callTool(env:Env,name:string,args:Record<string,unknown>):Promise<unknown>{
 switch(name){
  case "list_notes":{const paths=await listAllPaths(env);return{content:[{type:"text",text:paths.join("\n")||"(no notes)"}],structuredContent:{paths}};}
  case "search_notes":{const results=await searchNotes(env,String(args.query??""));return{content:[{type:"text",text:results.map(r=>`${r.path}\n${r.snippet}`).join("\n\n---\n\n")||"(no matches)"}],structuredContent:{results}};}
  case "read_note":{const path=safePath(args.path);const note=await getNote(env,path);if(!note)return{isError:true,content:[{type:"text",text:`Note not found: ${path}`}]};return{content:[{type:"text",text:note.content}],structuredContent:note};}
  case "write_note":{const path=safePath(args.path);const content=checkContent(args.content);const note=await putNote(env,path,content,Date.now());return{content:[{type:"text",text:`Saved ${path}`}],structuredContent:note};}
  case "delete_note":{const path=safePath(args.path);await env.VAULT_NOTES.delete(`note:${path}`);return{content:[{type:"text",text:`Deleted ${path}`}],structuredContent:{path,deleted:true}};}
  default: throw new Error(`Unknown tool: ${name}`);
 }
}
async function handleMcp(request:Request,env:Env){ if(request.method!=="POST")return new Response("MCP endpoint expects POST",{status:405}); let body:JsonRpcRequest; try{body=await request.json<JsonRpcRequest>();}catch{return rpcError(null,-32700,"Parse error");} try{switch(body.method){case"initialize":return rpcResult(body.id,{protocolVersion:"2025-06-18",capabilities:{tools:{}},serverInfo:{name:"vault-bridge",version:"0.1.0"}});case"notifications/initialized":return new Response(null,{status:202});case"ping":return rpcResult(body.id,{});case"tools/list":return rpcResult(body.id,{tools:TOOLS});case"tools/call":{const params=body.params??{};const name=String(params.name??"");const args=params.arguments&&typeof params.arguments==="object"?params.arguments as Record<string,unknown>:{};return rpcResult(body.id,await callTool(env,name,args));}default:return rpcError(body.id,-32601,"Method not found");}}catch(error){return rpcError(body.id,-32000,error instanceof Error?error.message:"Unknown error");}}
async function handleApi(request:Request,env:Env,url:URL){
 if(url.pathname==="/api/note"&&request.method==="PUT"){const data=await request.json<Record<string,unknown>>();const path=safePath(data.path);const content=checkContent(data.content);return json(await putNote(env,path,content,Number(data.mtime??Date.now())));}
 if(url.pathname==="/api/note"&&request.method==="GET"){const path=safePath(url.searchParams.get("path"));const note=await getNote(env,path);return note?json(note):json({error:"not_found"},404);}
 if(url.pathname==="/api/note"&&request.method==="DELETE"){const path=safePath(url.searchParams.get("path"));await env.VAULT_NOTES.delete(`note:${path}`);return json({path,deleted:true});}
 if(url.pathname==="/api/notes"&&request.method==="GET"){return json({results:await searchNotes(env,url.searchParams.get("q")??"")});}
 return json({error:"not_found"},404);
}
export default { async fetch(request:Request,env:Env){const url=new URL(request.url); if(url.pathname==="/health")return json({ok:true,service:"vault-bridge"}); if(!isAuthorized(request,env))return json({error:"unauthorized"},401); if(url.pathname==="/mcp")return handleMcp(request,env); if(url.pathname.startsWith("/api/")){try{return await handleApi(request,env,url);}catch(error){return json({error:error instanceof Error?error.message:"Bad request"},400);}} return json({service:"vault-bridge",endpoints:["/health","/api/note","/api/notes","/mcp"]}); } };
