import { App, Notice, Plugin, PluginSettingTab, Setting, TFile, requestUrl } from "obsidian";

interface VaultBridgeSettings { serverUrl: string; token: string; autoSync: boolean; }
const DEFAULT_SETTINGS: VaultBridgeSettings = { serverUrl: "", token: "", autoSync: false };
type RemoteNote = { path: string; content: string; mtime: number; updatedAt?: string };

export default class VaultBridgePlugin extends Plugin {
  settings: VaultBridgeSettings = DEFAULT_SETTINGS;
  private syncTimer: number | null = null;

  async onload() {
    await this.loadSettings();
    this.addSettingTab(new VaultBridgeSettingTab(this.app, this));
    this.addCommand({ id: "sync-current-note", name: "Sync current note", callback: () => this.syncCurrentNote() });
    this.addCommand({ id: "sync-all-markdown", name: "Sync all Markdown notes", callback: () => this.syncAllMarkdown() });
    this.addCommand({ id: "pull-current-note", name: "Pull current note from server", callback: () => this.pullCurrentNote() });
    this.registerEvent(this.app.vault.on("modify", (file) => {
      if (!this.settings.autoSync) return;
      if (!(file instanceof TFile) || file.extension !== "md") return;
      if (this.syncTimer !== null) window.clearTimeout(this.syncTimer);
      this.syncTimer = window.setTimeout(() => { void this.pushFile(file, false); this.syncTimer = null; }, 1200);
    }));
  }

  onunload() { if (this.syncTimer !== null) window.clearTimeout(this.syncTimer); }
  private baseUrl() { return this.settings.serverUrl.trim().replace(/\/+$/, ""); }
  private validateConfig() {
    if (!this.baseUrl()) { new Notice("Vault Bridge: configure o Server URL."); return false; }
    if (!this.settings.token.trim()) { new Notice("Vault Bridge: configure o token."); return false; }
    return true;
  }
  private headers(): Record<string,string> { return { Authorization: `Bearer ${this.settings.token.trim()}`, "Content-Type": "application/json" }; }

  async syncCurrentNote() {
    const file = this.app.workspace.getActiveFile();
    if (!file || file.extension !== "md") { new Notice("Vault Bridge: abra uma nota Markdown."); return; }
    await this.pushFile(file, true);
  }

  async syncAllMarkdown() {
    if (!this.validateConfig()) return;
    const files = this.app.vault.getMarkdownFiles(); let ok = 0, failed = 0;
    new Notice(`Vault Bridge: sincronizando ${files.length} notas...`);
    for (const file of files) {
      try { await this.pushFile(file, false); ok++; }
      catch (error) { console.error("Vault Bridge sync failed:", file.path, error); failed++; }
    }
    new Notice(`Vault Bridge: ${ok} sincronizadas, ${failed} falharam.`);
  }

  async pullCurrentNote() {
    if (!this.validateConfig()) return;
    const file = this.app.workspace.getActiveFile();
    if (!file || file.extension !== "md") { new Notice("Vault Bridge: abra uma nota Markdown."); return; }
    try {
      const url = `${this.baseUrl()}/api/note?path=${encodeURIComponent(file.path)}`;
      const response = await requestUrl({ url, method: "GET", headers: this.headers(), throw: false });
      if (response.status === 404) { new Notice("Vault Bridge: nota não existe no servidor."); return; }
      if (response.status < 200 || response.status >= 300) throw new Error(`HTTP ${response.status}: ${response.text}`);
      const remote = response.json as RemoteNote;
      await this.app.vault.modify(file, remote.content);
      new Notice(`Vault Bridge: ${file.path} atualizada do servidor.`);
    } catch (error) { console.error(error); new Notice("Vault Bridge: erro ao baixar nota."); }
  }

  private async pushFile(file: TFile, showNotice: boolean) {
    if (!this.validateConfig()) throw new Error("Missing configuration");
    const content = await this.app.vault.cachedRead(file);
    const response = await requestUrl({
      url: `${this.baseUrl()}/api/note`, method: "PUT", headers: this.headers(),
      body: JSON.stringify({ path: file.path, content, mtime: file.stat.mtime }), throw: false
    });
    if (response.status < 200 || response.status >= 300) throw new Error(`HTTP ${response.status}: ${response.text}`);
    if (showNotice) new Notice(`Vault Bridge: ${file.path} sincronizada.`);
  }

  async loadSettings() { this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData()); }
  async saveSettings() { await this.saveData(this.settings); }
}

class VaultBridgeSettingTab extends PluginSettingTab {
  plugin: VaultBridgePlugin;
  constructor(app: App, plugin: VaultBridgePlugin) { super(app, plugin); this.plugin = plugin; }
  display(): void {
    const { containerEl } = this; containerEl.empty();
    new Setting(containerEl).setName("Server URL").setDesc("Ex.: https://vault-bridge.seu-usuario.workers.dev")
      .addText(text => text.setPlaceholder("https://...").setValue(this.plugin.settings.serverUrl).onChange(async value => { this.plugin.settings.serverUrl = value.trim(); await this.plugin.saveSettings(); }));
    new Setting(containerEl).setName("Bridge token").setDesc("Mesmo token configurado no servidor remoto.")
      .addText(text => { text.inputEl.type = "password"; text.setPlaceholder("token secreto").setValue(this.plugin.settings.token).onChange(async value => { this.plugin.settings.token = value; await this.plugin.saveSettings(); }); });
    new Setting(containerEl).setName("Auto-sync").setDesc("Sincroniza a nota depois de salvar.")
      .addToggle(toggle => toggle.setValue(this.plugin.settings.autoSync).onChange(async value => { this.plugin.settings.autoSync = value; await this.plugin.saveSettings(); }));
  }
}
