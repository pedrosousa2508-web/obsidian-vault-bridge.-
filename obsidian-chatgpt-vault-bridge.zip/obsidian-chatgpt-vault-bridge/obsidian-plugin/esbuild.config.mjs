import esbuild from "esbuild";
import process from "process";
const prod = process.argv[2] === "production";
const ctx = await esbuild.context({
  entryPoints: ["main.ts"], bundle: true, external: ["obsidian"], format: "cjs",
  target: "es2018", logLevel: "info", sourcemap: prod ? false : "inline",
  treeShaking: true, outfile: "main.js"
});
if (prod) { await ctx.rebuild(); await ctx.dispose(); } else { await ctx.watch(); }
